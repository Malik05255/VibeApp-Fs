package com.vibe.app.feature.agent

import com.vibe.app.data.database.entity.MessageV2
import com.vibe.app.data.database.entity.PlatformV2
import com.vibe.app.feature.diagnostic.DiagnosticContext
import kotlinx.serialization.json.JsonElement

enum class AgentMessageRole {
    SYSTEM,
    USER,
    ASSISTANT,
    TOOL,
}

enum class AgentToolChoiceMode {
    NONE,
    AUTO,
    REQUIRED,
}

data class AgentLoopPolicy(
    // Complex Android generation can require dozens of sequential tool rounds
    // (resource creation, icon work, build, repair, and verification). Keep this
    // as a hard safety ceiling only; the loop still exits immediately on natural
    // completion, so increasing the ceiling does not make normal tasks run longer.
    val maxIterations: Int = 96,
    val toolChoiceMode: AgentToolChoiceMode = AgentToolChoiceMode.AUTO,
    val allowParallelToolCalls: Boolean = true,
)

data class AgentConversationItem(
    val role: AgentMessageRole,
    val text: String? = null,
    val attachments: List<String> = emptyList(),
    val toolCallId: String? = null,
    val toolName: String? = null,
    val payload: JsonElement? = null,
    // Non-null only for ASSISTANT items that ended with tool calls.
    // Used by stateless providers (e.g. Anthropic) to reconstruct full conversation history.
    val toolCalls: List<AgentToolCall>? = null,
    // Reasoning/thinking content from models that support it (e.g. Kimi kimi-k2.5).
    // Must be echoed back in subsequent turns for providers that require it.
    val reasoningContent: String? = null,
)

data class AgentToolDefinition(
    val name: String,
    val description: String,
    val inputSchema: JsonElement,
)

data class AgentToolCall(
    val id: String,
    val name: String,
    val arguments: JsonElement,
)

data class AgentToolResult(
    val toolCallId: String,
    val toolName: String,
    val output: JsonElement,
    val isError: Boolean = false,
)

data class AgentLoopRequest(
    val chatId: Int,
    val projectId: String? = null,
    val diagnosticContext: DiagnosticContext? = null,
    val platform: PlatformV2,
    val userMessages: List<MessageV2>,
    val assistantMessages: List<List<MessageV2>>,
    val systemPrompt: String? = null,
    val tools: List<AgentToolDefinition> = emptyList(),
    val policy: AgentLoopPolicy = AgentLoopPolicy(),
)

/**
 * Represents a single step in the agent's work process, displayed as an independent
 * item in the chat list. Each model iteration can produce multiple steps.
 */
data class AgentStepItem(
    val type: AgentStepType,
    val toolName: String? = null,
    val toolStatus: AgentToolStatus? = null,
    val content: String = "",
    val timestamp: Long = System.currentTimeMillis(),
    val plan: AgentPlan? = null,
    /** Consolidated tool calls for a single TOOL_CALL step per turn. */
    val toolCalls: List<ToolCallInfo> = emptyList(),
)

enum class AgentStepType {
    THINKING,
    TOOL_CALL,
    OUTPUT,
    PLAN,
}

enum class AgentToolStatus {
    CALLING,
    OK,
    ERROR,
}

data class ToolCallInfo(
    val toolName: String,
    val toolStatus: AgentToolStatus,
)

enum class PlanStepStatus {
    PENDING,
    IN_PROGRESS,
    COMPLETED,
    FAILED,
    SKIPPED,
}

data class AgentPlanStep(
    val id: Int,
    val description: String,
    val status: PlanStepStatus = PlanStepStatus.PENDING,
    val notes: String? = null,
)

data class AgentPlan(
    val summary: String,
    val steps: List<AgentPlanStep>,
    val createdAtIteration: Int,
)

sealed interface AgentLoopEvent {
    data class LoopStarted(
        val chatId: Int,
        val platformUid: String,
    ) : AgentLoopEvent

    data class ModelTurnStarted(
        val iteration: Int,
    ) : AgentLoopEvent

    data class ThinkingDelta(
        val iteration: Int,
        val delta: String,
    ) : AgentLoopEvent

    data class OutputDelta(
        val iteration: Int,
        val delta: String,
    ) : AgentLoopEvent

    data class ToolCallDiscovered(
        val iteration: Int,
        val call: AgentToolCall,
    ) : AgentLoopEvent

    data class ToolExecutionStarted(
        val iteration: Int,
        val call: AgentToolCall,
    ) : AgentLoopEvent

    data class ToolExecutionFinished(
        val iteration: Int,
        val result: AgentToolResult,
    ) : AgentLoopEvent

    data class LoopCompleted(
        val finalText: String,
        val toolResults: List<AgentToolResult> = emptyList(),
    ) : AgentLoopEvent

    data class LoopFailed(
        val message: String,
        val iteration: Int? = null,
    ) : AgentLoopEvent

    data class PlanCreated(
        val iteration: Int,
        val plan: AgentPlan,
    ) : AgentLoopEvent

    data class PlanUpdated(
        val iteration: Int,
        val plan: AgentPlan,
    ) : AgentLoopEvent
}